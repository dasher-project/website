To start the demo double-click on the start.bat  file.

The demo should be run in 16 bit colour and recorded at 640 by 480 pixels.

You can view any file individually by starting SCPLAYER.EXE
(double-click on it), opening the file you'd like to watch,
then pressing play.  (note: open is the open folder icon).



